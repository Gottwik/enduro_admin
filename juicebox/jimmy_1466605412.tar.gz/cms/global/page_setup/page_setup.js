{
	page_setup: {
		title: 'Kiska'
	}
}