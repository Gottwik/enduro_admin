{
	modules: [
		{
			module_type: 'kispander_image',
			context: {
				img: ''
			}
		}
	]
}